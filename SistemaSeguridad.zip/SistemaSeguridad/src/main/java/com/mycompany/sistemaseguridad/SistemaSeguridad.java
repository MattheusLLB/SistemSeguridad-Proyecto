package com.mycompany.sistemaseguridad;
import java.util.Scanner;
import org.bytedeco.opencv.opencv_core.Mat;
 
public class SistemaSeguridad {
 
    static Scanner sc = new Scanner(System.in);
 
    public static boolean validarCodigoRecuperacion(String codigoIngresado, String codigoReal) {
        return codigoIngresado.equals(codigoReal);
    }
 
    public static String nivelPorPuntaje(int puntos) {
        if (puntos <= 30) {
            return "RIESGO BAJO";
        } else if (puntos <= 60) {
            return "RIESGO MEDIO";
        } else if (puntos <= 80) {
            return "RIESGO ALTO";
                    
        } else {
            return "RIESGO CRITICO";
        }
    }
 
    public static double calcularPorcentaje(int parte, int total) {
        if (total > 0) {
            return (parte * 100.0) / total;
        } else {
            return 0;
        }
    }
 
    public static int puntajeAtaque(int opcionAtaque) {
        switch (opcionAtaque) {
            case 1:
                return 40;
            case 2:
                return 30;
            case 3:
                return 25;
            case 4:
                return 20;
            case 5:
                return 15;
            default:
                return 0;
        }
    }
 
    public static String nombreAtaque(int opcionAtaque) {
        switch (opcionAtaque) {
            case 1:
                return "Ataque por fuerza bruta";
            case 2:
                return "Robo de contrasenia";
            case 3:
                return "Intentos repetitivos";
            case 4:
                return "Dispositivo desconocido";
            case 5:
                return "Acceso fuera de horario";
            default:
                return "Ataque invalido";
        }
    }
 
    public static String crearRegistroMonitoreo(String usuario, String hora, String tipo, String resultado, String riesgo, String motivo) {
        return "Usuario: " + usuario
                + " | Hora: " + hora
                + " | Tipo: " + tipo
                + " | Resultado: " + resultado
                + " | Riesgo: " + riesgo
                + " | Motivo: " + motivo
                + " || ";
    }
 
    public static void mostrarNotas(String[][] notas, int[] contadorNotas, int usuarioActual) {
        System.out.println();
        System.out.println("===== NOTAS GUARDADAS =====");
 
        if (contadorNotas[usuarioActual] == 0) {
            System.out.println("No hay notas guardadas.");
        } else {
            for (int i = 0; i < contadorNotas[usuarioActual]; i++) {
                System.out.println("Nota [" + (i + 1) + "]: " + notas[usuarioActual][i]);
            }
        }
    }
 
    public static void mostrarCuentas(
            String[][] correoUni,
            String[][] usuarioUni,
            String[][] claveUni,
            int[][] confidencialidadCuenta,
            int[] contadorCuentas,
            int usuarioActual,
            int nivelAccesoUsuario
    ) {
        System.out.println();
        System.out.println("===== CUENTAS UNIVERSITARIAS =====");
 
        if (contadorCuentas[usuarioActual] == 0) {
            System.out.println("No hay cuentas universitarias guardadas.");
        } else {
            for (int i = 0; i < contadorCuentas[usuarioActual]; i++) {
                if (confidencialidadCuenta[usuarioActual][i] <= nivelAccesoUsuario) {
                    System.out.println("Cuenta [" + (i + 1) + "]");
                    System.out.println("Correo: " + correoUni[usuarioActual][i]);
                    System.out.println("Usuario: " + usuarioUni[usuarioActual][i]);
                    System.out.println("Contrasenia: " + claveUni[usuarioActual][i]);
                    System.out.println("Nivel de confidencialidad: " + confidencialidadCuenta[usuarioActual][i]);
                    System.out.println("-----------------------------");
                } else {
                    System.out.println("Cuenta [" + (i + 1) + "] no visible. Requiere mayor nivel de acceso.");
                }
            }
        }
    }
 
    public static void mostrarMonitoreoCompleto(StringBuilder monitoreoGeneral, int totalMonitoreo) {
        System.out.println();
        System.out.println("===== MONITOREO COMPLETO DEL SISTEMA =====");
 
        if (totalMonitoreo == 0) {
            System.out.println("No hay eventos registrados.");
        } else {
            System.out.println("Total de eventos registrados: " + totalMonitoreo);
            System.out.println();
            System.out.println(monitoreoGeneral);
        }
    }
 
    public static void mostrarReportes(
            int accesosExitosos,
            int accesosFallidos,
            int ataquesSimulados,
            int usuariosBloqueados,
            int totalUsuarios,
            int totalMonitoreo,
            double porcExito,
            double porcFallo,
            double porcAtaques,
            double porcBloqueos,
            double promedioIntentos,
            int[] contadorNotas,
            int[] contadorCuentas,
            int[] ataquesUsuario,
            int[] puntajeRiesgo,
            int usuarioActual
    ) {
        System.out.println();
        System.out.println("===== REPORTES Y ESTADISTICAS =====");
        System.out.println("Accesos exitosos: " + accesosExitosos);
        System.out.println("Accesos fallidos: " + accesosFallidos);
        System.out.println("Usuarios registrados: " + totalUsuarios);
        System.out.println("Bloqueos generales del programa: " + usuariosBloqueados);
        System.out.println("Ataques simulados: " + ataquesSimulados);
        System.out.println("Eventos registrados en monitoreo: " + totalMonitoreo);
        System.out.println("Porcentaje de accesos exitosos: " + porcExito + "%");
        System.out.println("Porcentaje de accesos rechazados: " + porcFallo + "%");
        System.out.println("Porcentaje de bloqueos del programa: " + porcBloqueos + "%");
        System.out.println("Porcentaje de ataques simulados: " + porcAtaques + "%");
        System.out.println("Promedio de intentos por usuario: " + promedioIntentos);
 
        System.out.println();
        System.out.println("===== DATOS DEL USUARIO ACTUAL =====");
        System.out.println("Notas guardadas: " + contadorNotas[usuarioActual]);
        System.out.println("Cuentas universitarias guardadas: " + contadorCuentas[usuarioActual]);
        System.out.println("Ataques simulados por este usuario: " + ataquesUsuario[usuarioActual]);
        System.out.println("Puntaje de riesgo actual: " + puntajeRiesgo[usuarioActual]);
        System.out.println("Nivel de riesgo actual: " + nivelPorPuntaje(puntajeRiesgo[usuarioActual]));
 
        System.out.println();
        System.out.println("===== REPORTE MATEMATICO DEL RIESGO =====");
        System.out.println("Intento fallido = +20");
        System.out.println("Error OTP = +30");
        System.out.println("Fallo biometrico = +40");
        System.out.println("Ataque por fuerza bruta = +40");
        System.out.println("Robo de contrasenia = +30");
        System.out.println("Intentos repetitivos = +25");
        System.out.println("Dispositivo desconocido = +20");
        System.out.println("Acceso fuera de horario = +15");
        System.out.println("Total actual del usuario: " + puntajeRiesgo[usuarioActual]);
        System.out.println("Clasificacion: " + nivelPorPuntaje(puntajeRiesgo[usuarioActual]));
    }
 
    public static int leerEntero() {
        while (!sc.hasNextInt()) {
            System.out.println("Ingrese un numero entero valido:");
            sc.nextLine();
        }
        int valor = sc.nextInt();
        sc.nextLine();
        return valor;
    }
 
    public static double leerReal() {
        while (!sc.hasNextDouble()) {
            System.out.println("Ingrese un numero real valido:");
            sc.nextLine();
        }
        double valor = sc.nextDouble();
        sc.nextLine();
        return valor;
    }
 
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] nombres = new String[10];
        String[] usuarios = new String[10];
        String[] claves = new String[10];
        String[] codigosRecuperacion = new String[10];
        String[] estadoCuenta = new String[10];
        String[] correosUsuarios = new String[10];
 
        String[][] notas = new String[10][10];
        String[][] correoUni = new String[10][10];
        String[][] usuarioUni = new String[10][10];
        String[][] claveUni = new String[10][10];
 
        int[] contadorNotas = new int[10];
        int[] contadorCuentas = new int[10];
        int[] ataquesUsuario = new int[10];
        int[] puntajeRiesgo = new int[10];
        int[] intentosUsuario = new int[10];
        int[] nivelAcceso = new int[10];
 
        int[][] confidencialidadCuenta = new int[10][10];
 
        String userIngresado;
        String passIngresada;
        String nuevoNombre;
        String nuevoUsuario;
        String nuevoCorreo;
        String nuevaClave;
        String codigoOTP;
        String codigoIngresado;
        String horaSimulada = "";
        String correoIngresado;
        String correoSistema = "test1@gmail.com";
        String codigoSistema = "ML123";
 
        StringBuilder monitoreoGeneral = new StringBuilder();
        String registroMonitor;
 
        int intentos;
        int opcionInicio;
        int opcionMenu;
        int opcionAtaque;
        int totalUsuarios = 1;
        int accesosExitosos = 0;
        int accesosFallidos = 0;
        int ataquesSimulados = 0;
        int usuariosBloqueados = 0;
        int usuarioActual;
        int puntosAtaque;
        int totalMonitoreo = 0;
        int totalAccesos;
        int totalIntentos;
 
        double porcExito;
        double porcFallo;
        double porcAtaques;
        double porcBloqueos;
        double promedioIntentos;
 
        boolean accesoConcedido;
        boolean biometriaOk;
        boolean otpOk;
        boolean sistemaActivo = true;
        boolean sesionActiva;
        boolean existeUsuario;
        boolean cerrarSesion;
        boolean programaBloqueado = false;
 
        nombres[0] = "Usuario de prueba";
        usuarios[0] = "Test1";
        claves[0] = "grupo123";
        codigosRecuperacion[0] = "ML123";
        estadoCuenta[0] = "ACTIVA";
        nivelAcceso[0] = 3;
        correosUsuarios[0] = correoSistema;
 
        while (sistemaActivo) {
 
            if (programaBloqueado) {
 
                System.out.println();
                System.out.println("======================================");
                System.out.println(" SISTEMA BLOQUEADO POR SEGURIDAD");
                System.out.println("======================================");
                System.out.println("Se detectaron 5 intentos fallidos.");
                System.out.println("Factor de peligrosidad: ALTO");
                System.out.println("Debe verificar correo electronico y codigo de 2 factores.");
 
                System.out.println();
                System.out.println("Ingrese correo electronico para mandar codigo de verificacion:");
                correoIngresado = sc.nextLine();
 
                if (correoIngresado.equals(correoSistema)) {
 
                    System.out.println("Correo verificado. Codigo enviado correctamente.");
                    System.out.println("Ingrese codigo de 2 factores:");
                    codigoIngresado = sc.nextLine();
 
                    if (codigoIngresado.equals(codigoSistema)) {
                        System.out.println("Codigo correcto. Programa desbloqueado.");
 
                        programaBloqueado = false;
                        intentos = 0;
 
                        registroMonitor = crearRegistroMonitoreo(
                                "Sistema",
                                "Recuperacion",
                                "Bloqueo general",
                                "Desbloqueado",
                                "RIESGO BAJO",
                                "Correo y codigo de 2 factores correctos"
                        );
                        monitoreoGeneral.append(registroMonitor);
                        totalMonitoreo++;
 
                    } else {
                        System.out.println("Codigo incorrecto. El programa sigue bloqueado.");
 
                        registroMonitor = crearRegistroMonitoreo(
                                "Sistema",
                                "Recuperacion",
                                "Bloqueo general",
                                "Rechazado",
                                "RIESGO ALTO",
                                "Codigo de 2 factores incorrecto"
                        );
                        monitoreoGeneral.append(registroMonitor);
                        totalMonitoreo++;
                    }
 
                } else {
                    System.out.println("Correo incorrecto. No se envio el codigo.");
                    System.out.println("El programa sigue bloqueado.");
 
                    registroMonitor = crearRegistroMonitoreo(
                            "Sistema",
                            "Recuperacion",
                            "Bloqueo general",
                            "Rechazado",
                            "RIESGO ALTO",
                            "Correo de recuperacion incorrecto"
                    );
                    monitoreoGeneral.append(registroMonitor);
                    totalMonitoreo++;
                }
 
            } else {
 
                System.out.println();
                System.out.println("======================================");
                System.out.println(" SISTEMA DE CIBERSEGURIDAD Y BOVEDA");
                System.out.println("======================================");
                System.out.println("1. Iniciar sesion");
                System.out.println("2. Registrarse");
                System.out.println("3. Salir");
                opcionInicio = leerEntero();
 
                switch (opcionInicio) {
 
                    case 1:
                        intentos = 0;
                        accesoConcedido = false;
                        biometriaOk = false;
                        otpOk = false;
                        sesionActiva = false;
                        usuarioActual = -1;
 
                        do {
                            System.out.println();
                            System.out.println("=== INICIO DE SESION SEGURA ===");
                            System.out.println("Usuario:");
                            userIngresado = sc.nextLine();
                            System.out.println("Contrasenia:");
                            passIngresada = sc.nextLine();
                            System.out.println("Hora simulada de acceso:");
                            horaSimulada = sc.nextLine();
 
                            accesoConcedido = false;
                            usuarioActual = -1;
 
                            for (int i = 0; i < totalUsuarios; i++) {
                                if (usuarios[i].equals(userIngresado)) {
                                    usuarioActual = i;
                                }
                            }
 
                            if (usuarioActual == -1) {
                                intentos++;
                                accesosFallidos++;
 
                                System.out.println("Usuario no existe. Intento " + intentos + "/5");
 
                                registroMonitor = crearRegistroMonitoreo(
                                        userIngresado,
                                        horaSimulada,
                                        "Credenciales",
                                        "Rechazado",
                                        "SIN RIESGO",
                                        "Usuario no existe"
                                );
                                monitoreoGeneral.append(registroMonitor);
                                totalMonitoreo++;
 
                            } else {
 
                                if (claves[usuarioActual].equals(passIngresada) && !passIngresada.equals("")) {
                                    accesoConcedido = true;
                                } else {
                                    accesoConcedido = false;
                                }
 
                                if (accesoConcedido) {
 
                                    String codigoGenerado = EnvioCorreo.generarCodigo();
                                    boolean correoEnviado = EnvioCorreo.enviarCodigo(correosUsuarios[usuarioActual], codigoGenerado);
 
                                    if (correoEnviado) {
                                        System.out.println("Codigo enviado a " + correosUsuarios[usuarioActual]);
                                        System.out.println("Ingrese el codigo recibido:");
                                        codigoOTP = sc.nextLine();
                                        otpOk = codigoOTP.equals(codigoGenerado);
                                    } else {
                                        System.out.println("No se pudo enviar el codigo de verificacion.");
                                        otpOk = false;
                                    }
 
                                    if (otpOk) {
 
                                        System.out.println("Verificando tu rostro con la camara...");
                                        Mat rostroCapturado = ReconocimientoFacialCamara.capturarRostro();
 
                                        biometriaOk = ReconocimientoFacialCamara.verificarIdentidad(
                                                usuarios[usuarioActual],
                                                rostroCapturado,
                                                60
                                        );
 
                                        if (biometriaOk) {
                                            System.out.println("Identidad confirmada. Accediendo al sistema...");
 
                                            accesosExitosos++;
                                            sesionActiva = true;
 
                                            registroMonitor = crearRegistroMonitoreo(
                                                    userIngresado,
                                                    horaSimulada,
                                                    "Contrasenia, OTP y biometria",
                                                    "Aceptado",
                                                    nivelPorPuntaje(puntajeRiesgo[usuarioActual]),
                                                    "Acceso correcto"
                                            );
                                            monitoreoGeneral.append(registroMonitor);
                                            totalMonitoreo++;
 
                                        } else {
                                            System.out.println("Falla biometrica. Debe iniciar sesion nuevamente.");
 
                                            intentos++;
                                            accesosFallidos++;
                                            intentosUsuario[usuarioActual]++;
                                            puntajeRiesgo[usuarioActual] += 40;
 
                                            registroMonitor = crearRegistroMonitoreo(
                                                    userIngresado,
                                                    horaSimulada,
                                                    "Biometria",
                                                    "Rechazado",
                                                    nivelPorPuntaje(puntajeRiesgo[usuarioActual]),
                                                    "Similitud menor a 0.8 o valor fuera de rango"
                                            );
                                            monitoreoGeneral.append(registroMonitor);
                                            totalMonitoreo++;
                                        }
 
                                    } else {
                                        System.out.println("Codigo OTP incorrecto.");
 
                                        intentos++;
                                        accesosFallidos++;
                                        intentosUsuario[usuarioActual]++;
                                        puntajeRiesgo[usuarioActual] += 30;
 
                                        registroMonitor = crearRegistroMonitoreo(
                                                userIngresado,
                                                horaSimulada,
                                                "OTP",
                                                "Rechazado",
                                                nivelPorPuntaje(puntajeRiesgo[usuarioActual]),
                                                "Codigo OTP incorrecto"
                                        );
                                        monitoreoGeneral.append(registroMonitor);
                                        totalMonitoreo++;
                                    }
 
                                } else {
                                    intentos++;
                                    accesosFallidos++;
                                    intentosUsuario[usuarioActual]++;
                                    puntajeRiesgo[usuarioActual] += 20;
 
                                    System.out.println("Error. Intento " + intentos + "/5");
                                    System.out.println("Nivel de riesgo: " + nivelPorPuntaje(puntajeRiesgo[usuarioActual]));
 
                                    registroMonitor = crearRegistroMonitoreo(
                                            userIngresado,
                                            horaSimulada,
                                            "Credenciales",
                                            "Rechazado",
                                            nivelPorPuntaje(puntajeRiesgo[usuarioActual]),
                                            "Usuario o contrasenia incorrectos"
                                    );
                                    monitoreoGeneral.append(registroMonitor);
                                    totalMonitoreo++;
                                }
                            }
 
                            if (intentos == 5) {
                                programaBloqueado = true;
                                usuariosBloqueados++;
 
                                System.out.println();
                                System.out.println("ALERTA: PROGRAMA BLOQUEADO.");
                                System.out.println("Motivo: Se alcanzaron 5 intentos fallidos.");
                                System.out.println("Factor de peligrosidad: ALTO");
 
                                if (usuarioActual != -1) {
                                    if (puntajeRiesgo[usuarioActual] < 80) {
                                        puntajeRiesgo[usuarioActual] = 80;
                                    }
 
                                    System.out.println("Usuario relacionado: " + usuarios[usuarioActual]);
                                    System.out.println("Puntaje de riesgo del usuario: " + puntajeRiesgo[usuarioActual]);
                                    System.out.println("Nivel de riesgo: " + nivelPorPuntaje(puntajeRiesgo[usuarioActual]));
                                } else {
                                    System.out.println("No se encontro un usuario especifico.");
                                    System.out.println("Aun asi, el programa queda bloqueado por seguridad.");
                                }
 
                                registroMonitor = crearRegistroMonitoreo(
                                        userIngresado,
                                        horaSimulada,
                                        "Bloqueo general",
                                        "Bloqueado",
                                        "RIESGO ALTO",
                                        "Cinco intentos fallidos. Factor de peligrosidad alto"
                                );
                                monitoreoGeneral.append(registroMonitor);
                                totalMonitoreo++;
                            }
 
                        } while (!sesionActiva && intentos != 5);
 
                        if (sesionActiva) {
                            cerrarSesion = false;
 
                            do {
                                System.out.println();
                                System.out.println("------------------------------------");
                                System.out.println("MENU DE CIBERSEGURIDAD");
                                System.out.println("Usuario actual: " + usuarios[usuarioActual]);
                                System.out.println("Nivel de acceso: " + nivelAcceso[usuarioActual]);
                                System.out.println("1. Guardar Nota");
                                System.out.println("2. Ver Notas");
                                System.out.println("3. Guardar Cuenta Universitaria");
                                System.out.println("4. Ver Cuentas Universitarias");
                                System.out.println("5. Simulacion de Ataques");
                                System.out.println("6. Reportes y Estadisticas");
                                System.out.println("7. Ver monitoreo completo");
                                System.out.println("8. Cerrar sesion");
                                opcionMenu = leerEntero();
 
                                switch (opcionMenu) {
 
                                    case 1:
                                        if (contadorNotas[usuarioActual] < 10) {
                                            System.out.println("Texto de la nota:");
                                            notas[usuarioActual][contadorNotas[usuarioActual]] = sc.nextLine();
 
                                            contadorNotas[usuarioActual]++;
 
                                            System.out.println("Nota guardada correctamente.");
 
                                            registroMonitor = crearRegistroMonitoreo(
                                                    usuarios[usuarioActual],
                                                    "Sesion activa",
                                                    "Boveda",
                                                    "Registrado",
                                                    nivelPorPuntaje(puntajeRiesgo[usuarioActual]),
                                                    "Nota guardada"
                                            );
                                            monitoreoGeneral.append(registroMonitor);
                                            totalMonitoreo++;
                                        } else {
                                            System.out.println("NO HAY ESPACIO PARA MAS NOTAS.");
                                        }
                                        break;
 
                                    case 2:
                                        mostrarNotas(notas, contadorNotas, usuarioActual);
                                        break;
 
                                    case 3:
                                        if (contadorCuentas[usuarioActual] < 10) {
                                            System.out.println("Correo electronico:");
                                            correoUni[usuarioActual][contadorCuentas[usuarioActual]] = sc.nextLine();
 
                                            System.out.println("Usuario:");
                                            usuarioUni[usuarioActual][contadorCuentas[usuarioActual]] = sc.nextLine();
 
                                            System.out.println("Contrasenia:");
                                            claveUni[usuarioActual][contadorCuentas[usuarioActual]] = sc.nextLine();
 
                                            System.out.println("Nivel de confidencialidad de la cuenta 1 a 3:");
                                            confidencialidadCuenta[usuarioActual][contadorCuentas[usuarioActual]] = leerEntero();
 
                                            if (confidencialidadCuenta[usuarioActual][contadorCuentas[usuarioActual]] < 1) {
                                                confidencialidadCuenta[usuarioActual][contadorCuentas[usuarioActual]] = 1;
                                            }
 
                                            if (confidencialidadCuenta[usuarioActual][contadorCuentas[usuarioActual]] > 3) {
                                                confidencialidadCuenta[usuarioActual][contadorCuentas[usuarioActual]] = 3;
                                            }
 
                                            contadorCuentas[usuarioActual]++;
 
                                            System.out.println("Cuenta universitaria guardada.");
 
                                            registroMonitor = crearRegistroMonitoreo(
                                                    usuarios[usuarioActual],
                                                    "Sesion activa",
                                                    "Boveda",
                                                    "Registrado",
                                                    nivelPorPuntaje(puntajeRiesgo[usuarioActual]),
                                                    "Cuenta universitaria guardada"
                                            );
                                            monitoreoGeneral.append(registroMonitor);
                                            totalMonitoreo++;
 
                                        } else {
                                            System.out.println("NO HAY ESPACIO PARA MAS CUENTAS.");
                                        }
                                        break;
 
                                    case 4:
                                        mostrarCuentas(
                                                correoUni,
                                                usuarioUni,
                                                claveUni,
                                                confidencialidadCuenta,
                                                contadorCuentas,
                                                usuarioActual,
                                                nivelAcceso[usuarioActual]
                                        );
                                        break;
 
                                    case 5:
                                        System.out.println();
                                        System.out.println("===== SIMULACION DE ATAQUES =====");
                                        System.out.println("1. Ataque por fuerza bruta");
                                        System.out.println("2. Robo de contrasenia");
                                        System.out.println("3. Intentos repetitivos");
                                        System.out.println("4. Dispositivo desconocido");
                                        System.out.println("5. Acceso fuera de horario");
                                        opcionAtaque = leerEntero();
 
                                        puntosAtaque = puntajeAtaque(opcionAtaque);
 
                                        if (puntosAtaque > 0) {
                                            ataquesSimulados++;
                                            ataquesUsuario[usuarioActual]++;
                                            puntajeRiesgo[usuarioActual] += puntosAtaque;
 
                                            System.out.println(nombreAtaque(opcionAtaque) + " registrado. +" + puntosAtaque + " riesgo.");
                                            System.out.println("Nuevo nivel de riesgo: " + nivelPorPuntaje(puntajeRiesgo[usuarioActual]));
 
                                            registroMonitor = crearRegistroMonitoreo(
                                                    usuarios[usuarioActual],
                                                    "Sesion activa",
                                                    nombreAtaque(opcionAtaque),
                                                    "Registrado",
                                                    nivelPorPuntaje(puntajeRiesgo[usuarioActual]),
                                                    "Ataque simulado"
                                            );
                                            monitoreoGeneral.append(registroMonitor);
                                            totalMonitoreo++;
 
                                            if (nivelPorPuntaje(puntajeRiesgo[usuarioActual]).equals("RIESGO CRITICO")) {
                                                programaBloqueado = true;
                                                usuariosBloqueados++;
 
                                                System.out.println("Programa bloqueado por riesgo critico.");
 
                                                registroMonitor = crearRegistroMonitoreo(
                                                        usuarios[usuarioActual],
                                                        "Sesion activa",
                                                        "Bloqueo general",
                                                        "Bloqueado",
                                                        nivelPorPuntaje(puntajeRiesgo[usuarioActual]),
                                                        "Riesgo critico alcanzado por ataques"
                                                );
                                                monitoreoGeneral.append(registroMonitor);
                                                totalMonitoreo++;
 
                                                cerrarSesion = true;
                                            }
 
                                        } else {
                                            System.out.println("Opcion invalida.");
                                        }
                                        break;
 
                                    case 6:
                                        totalAccesos = accesosExitosos + accesosFallidos;
                                        totalIntentos = 0;
 
                                        for (int i = 0; i < totalUsuarios; i++) {
                                            totalIntentos += intentosUsuario[i];
                                        }
 
                                        porcExito = calcularPorcentaje(accesosExitosos, totalAccesos);
                                        porcFallo = calcularPorcentaje(accesosFallidos, totalAccesos);
                                        porcAtaques = calcularPorcentaje(ataquesSimulados, totalAccesos + ataquesSimulados);
                                        porcBloqueos = calcularPorcentaje(usuariosBloqueados, totalUsuarios);
 
                                        if (totalUsuarios > 0) {
                                            promedioIntentos = totalIntentos * 1.0 / totalUsuarios;
                                        } else {
                                            promedioIntentos = 0;
                                        }
 
                                        mostrarReportes(
                                                accesosExitosos,
                                                accesosFallidos,
                                                ataquesSimulados,
                                                usuariosBloqueados,
                                                totalUsuarios,
                                                totalMonitoreo,
                                                porcExito,
                                                porcFallo,
                                                porcAtaques,
                                                porcBloqueos,
                                                promedioIntentos,
                                                contadorNotas,
                                                contadorCuentas,
                                                ataquesUsuario,
                                                puntajeRiesgo,
                                                usuarioActual
                                        );
                                        break;
 
                                    case 7:
                                        mostrarMonitoreoCompleto(monitoreoGeneral, totalMonitoreo);
                                        break;
 
                                    case 8:
                                        System.out.println("Sesion cerrada.");
                                        cerrarSesion = true;
                                        break;
 
                                    default:
                                        System.out.println("Opcion invalida.");
                                        break;
                                }
 
                            } while (!cerrarSesion);
                        }
 
                        break;
 
                    case 2:
                        if (totalUsuarios < 10) {
                            System.out.println();
                            System.out.println("=== REGISTRO DE USUARIO ===");
 
                            System.out.println("Nombre completo:");
                            nuevoNombre = sc.nextLine();
 
                            System.out.println("Nuevo usuario:");
                            nuevoUsuario = sc.nextLine();
 
                            System.out.println("Correo electronico (para el codigo de verificacion):");
                            nuevoCorreo = sc.nextLine();
 
                            existeUsuario = false;
 
                            for (int i = 0; i < totalUsuarios; i++) {
                                if (usuarios[i].equals(nuevoUsuario)) {
                                    existeUsuario = true;
                                }
                            }
 
                            if (existeUsuario) {
                                System.out.println("Ese usuario ya existe. No se puede registrar repetido.");
                            } else {
                                System.out.println("Nueva contrasenia:");
                                nuevaClave = sc.nextLine();
 
                                if (!nuevaClave.equals("")) {
                                    nombres[totalUsuarios] = nuevoNombre;
                                    usuarios[totalUsuarios] = nuevoUsuario;
                                    claves[totalUsuarios] = nuevaClave;
                                    correosUsuarios[totalUsuarios] = nuevoCorreo;
 
                                    System.out.println("Ahora vamos a registrar tu rostro. Mira a la camara...");
                                    Mat rostroRegistro = ReconocimientoFacialCamara.capturarRostro();
 
                                    if (ReconocimientoFacialCamara.guardarFotoReferencia(nuevoUsuario, rostroRegistro)) {
                                        System.out.println("Rostro registrado correctamente.");
                                    } else {
                                        System.out.println("No se pudo capturar tu rostro. Podras intentar registrarlo mas adelante.");
                                    }
 
                                    System.out.println("Codigo de recuperacion:");
                                    codigosRecuperacion[totalUsuarios] = sc.nextLine();
 
                                    System.out.println("Nivel de acceso 1 a 3:");
                                    nivelAcceso[totalUsuarios] = leerEntero();
 
                                    if (nivelAcceso[totalUsuarios] < 1) {
                                        nivelAcceso[totalUsuarios] = 1;
                                    }
 
                                    if (nivelAcceso[totalUsuarios] > 3) {
                                        nivelAcceso[totalUsuarios] = 3;
                                    }
 
                                    estadoCuenta[totalUsuarios] = "ACTIVA";
 
                                    System.out.println("Usuario registrado correctamente.");
 
                                    registroMonitor = crearRegistroMonitoreo(
                                            nuevoUsuario,
                                            "Registro",
                                            "Usuario",
                                            "Registrado",
                                            "RIESGO BAJO",
                                            "Nuevo usuario creado"
                                    );
                                    monitoreoGeneral.append(registroMonitor);
                                    totalMonitoreo++;
 
                                    totalUsuarios++;
 
                                } else {
                                    System.out.println("La contrasenia no puede estar vacia.");
 
                                    registroMonitor = crearRegistroMonitoreo(
                                            nuevoUsuario,
                                            "Registro",
                                            "Usuario",
                                            "Rechazado",
                                            "SIN RIESGO",
                                            "Contrasenia vacia"
                                    );
                                    monitoreoGeneral.append(registroMonitor);
                                    totalMonitoreo++;
                                }
                            }
 
                        } else {
                            System.out.println("NO HAY ESPACIO PARA MAS USUARIOS.");
 
                            registroMonitor = crearRegistroMonitoreo(
                                    "Sistema",
                                    "Registro",
                                    "Usuarios",
                                    "Rechazado",
                                    "SIN RIESGO",
                                    "Limite de usuarios alcanzado"
                            );
                            monitoreoGeneral.append(registroMonitor);
                            totalMonitoreo++;
                        }
                        break;
 
                    case 3:
                        System.out.println("Programa finalizado de forma segura.");
 
                        registroMonitor = crearRegistroMonitoreo(
                                "Sistema",
                                "Salida",
                                "Programa",
                                "Finalizado",
                                "SIN RIESGO",
                                "El usuario salio del sistema"
                        );
                        monitoreoGeneral.append(registroMonitor);
                        totalMonitoreo++;
 
                        sistemaActivo = false;
                        break;
 
                    default:
                        System.out.println("Opcion invalida.");
 
                        registroMonitor = crearRegistroMonitoreo(
                                "Sistema",
                                "Menu principal",
                                "Opcion",
                                "Rechazado",
                                "SIN RIESGO",
                                "Opcion invalida en menu principal"
                        );
                        monitoreoGeneral.append(registroMonitor);
                        totalMonitoreo++;
                        break;
                }
            }
        }
    }
}