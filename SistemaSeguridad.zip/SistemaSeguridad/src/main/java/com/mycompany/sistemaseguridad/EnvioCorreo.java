package com.mycompany.sistemaseguridad;
 
import jakarta.mail.*;
import jakarta.mail.internet.*;
import java.util.Properties;
 
public class EnvioCorreo {
 
    // === CONFIGURA ESTOS DOS DATOS ===
    private static final String EMAIL_REMITENTE = "tucuenta@gmail.com";
    private static final String CLAVE_APP = "xxxx xxxx xxxx xxxx"; // Contraseña de aplicacion de Gmail (16 caracteres)
 
    /**
     * Genera un codigo aleatorio de 6 digitos.
     */
    public static String generarCodigo() {
        int numero = (int) (Math.random() * 900000) + 100000;
        return String.valueOf(numero);
    }
 
    /**
     * Envia el codigo OTP al correo indicado.
     * Devuelve true si el envio fue exitoso, false si hubo un error.
     */
    public static boolean enviarCodigo(String destinatario, String codigo) {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
 
        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(EMAIL_REMITENTE, CLAVE_APP);
            }
        });
 
        try {
            Message mensaje = new MimeMessage(session);
            mensaje.setFrom(new InternetAddress(EMAIL_REMITENTE));
            mensaje.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            mensaje.setSubject("Codigo de verificacion - Sistema de Seguridad");
            mensaje.setText(
                "Tu codigo de verificacion es: " + codigo + "\n\n" +
                "Este codigo es valido solo para este intento de inicio de sesion.\n" +
                "Si no solicitaste este codigo, ignora este mensaje."
            );
 
            Transport.send(mensaje);
            return true;
 
        } catch (MessagingException e) {
            System.out.println("Error enviando el correo: " + e.getMessage());
            return false;
        }
    }
}
 