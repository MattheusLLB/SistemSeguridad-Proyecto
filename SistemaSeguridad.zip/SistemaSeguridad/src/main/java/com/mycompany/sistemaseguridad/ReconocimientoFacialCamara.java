package com.mycompany.sistemaseguridad;
 
import org.bytedeco.javacv.*;
import org.bytedeco.opencv.opencv_core.*;
import org.bytedeco.opencv.opencv_objdetect.CascadeClassifier;
import org.bytedeco.opencv.opencv_face.LBPHFaceRecognizer;
import org.bytedeco.javacpp.indexer.IntIndexer;
 
import java.io.File;
 
import static org.bytedeco.opencv.global.opencv_imgproc.*;
import static org.bytedeco.opencv.global.opencv_imgcodecs.*;
import static org.bytedeco.opencv.global.opencv_core.*;
 
public class ReconocimientoFacialCamara {
 
    private static final String RUTA_CASCADE = "haarcascade_frontalface_default.xml";
    private static final String CARPETA_FOTOS = "fotos_usuarios";
    private static CascadeClassifier detector;
 
    static {
        detector = new CascadeClassifier(RUTA_CASCADE);
        new File(CARPETA_FOTOS).mkdirs();
    }
 
    /**
     * Abre la camara, espera un momento y captura un rostro.
     * Devuelve la imagen del rostro (en escala de grises, 200x200) o null si no detecto ningun rostro.
     */
    public static Mat capturarRostro() {
        OpenCVFrameGrabber grabber = new OpenCVFrameGrabber(0); // 0 = camara por defecto
        OpenCVFrameConverter.ToMat converter = new OpenCVFrameConverter.ToMat();
 
        try {
            grabber.start();
            System.out.println("Camara iniciada. Mira directamente a la camara...");
            Thread.sleep(2000); // deja que la camara se estabilice (enfoque, exposicion)
 
            Mat rostroEncontrado = null;
            int intentos = 0;
 
            // Intenta varias veces por si el primer frame no detecta bien el rostro
            while (rostroEncontrado == null && intentos < 15) {
                Frame frame = grabber.grab();
                Mat imagen = converter.convert(frame);
 
                Mat gris = new Mat();
                cvtColor(imagen, gris, COLOR_BGR2GRAY);
                equalizeHist(gris, gris);
 
                RectVector rostros = new RectVector();
                detector.detectMultiScale(gris, rostros);
 
                if (rostros.size() > 0) {
                    Rect zona = rostros.get(0);
                    Mat recorte = new Mat(gris, zona);
                    Mat redimensionado = new Mat();
                    resize(recorte, redimensionado, new Size(200, 200));
                    rostroEncontrado = redimensionado;
                }
 
                intentos++;
                Thread.sleep(150);
            }
 
            grabber.stop();
            return rostroEncontrado;
 
        } catch (Exception e) {
            System.out.println("Error accediendo a la camara: " + e.getMessage());
            try { grabber.stop(); } catch (Exception ignored) {}
            return null;
        }
    }
 
    /**
     * Guarda la foto de referencia de un usuario (usada en el registro).
     */
    public static boolean guardarFotoReferencia(String nombreUsuario, Mat rostro) {
        if (rostro == null) return false;
        String ruta = CARPETA_FOTOS + "/" + nombreUsuario + ".png";
        return imwrite(ruta, rostro);
    }
 
    /**
     * Compara el rostro capturado en el login contra la foto de referencia del usuario.
     * Devuelve true si se considera la misma persona, segun el umbral de confianza.
     */
    public static boolean verificarIdentidad(String nombreUsuario, Mat rostroNuevo, double umbralConfianza) {
        if (rostroNuevo == null) {
            System.out.println("No se detecto ningun rostro frente a la camara.");
            return false;
        }
 
        String ruta = CARPETA_FOTOS + "/" + nombreUsuario + ".png";
        Mat rostroReferencia = imread(ruta, IMREAD_GRAYSCALE);
 
        if (rostroReferencia.empty()) {
            System.out.println("Este usuario no tiene una foto de referencia registrada.");
            return false;
        }
 
        LBPHFaceRecognizer recognizer = LBPHFaceRecognizer.create();
 
        MatVector imagenes = new MatVector(1);
        imagenes.put(0, rostroReferencia);
 
        Mat etiquetas = new Mat(1, 1, CV_32SC1);
        IntIndexer indexador = etiquetas.createIndexer();
        indexador.put(0, 0, 1);
 
        recognizer.train(imagenes, etiquetas);
 
        int[] etiquetaPredicha = new int[1];
        double[] confianza = new double[1];
        recognizer.predict(rostroNuevo, etiquetaPredicha, confianza);
 
        System.out.println("Distancia obtenida: " + confianza[0] + " (umbral: " + umbralConfianza + ")");
 
        // En LBPH, MENOR distancia = MAS parecido (al reves que un "0.0 a 1.0" de similitud)
        // Un umbral tipico razonable esta entre 50 y 70 dependiendo de iluminacion/camara
        return confianza[0] < umbralConfianza;
    }
}
 